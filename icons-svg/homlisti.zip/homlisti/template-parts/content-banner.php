<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\HomListi;

if ( RDTheme::$has_breadcrumb ):
	do_action( 'homlisti_breadcrumb' );
endif;