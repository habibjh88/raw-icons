<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\HomListi;

use Rtcl\Controllers\Hooks\AppliedBothEndHooks;
use Rtcl\Helpers\Breadcrumb;
use Rtcl\Helpers\Functions;

class HomlistiAjax {

	protected static $instance = null;

	public function __construct() {
		add_action( 'wp_ajax_homlist_app_notice_dismiss', [ $this, 'homlist_app_notice_dismiss' ] );

		//Old Custom Fields ajax callback
		add_action( 'wp_ajax_rtcl_cf_by_category', [ $this, 'rtcl_cf_by_category_func' ] );
		add_action( 'wp_ajax_nopriv_rtcl_cf_by_category', [ $this, 'rtcl_cf_by_category_func' ] );
	}

	/**
	 * Make class instance
	 *
	 * @return self|null
	 */
	public static function instance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Ajax Functionality for Remove App Notice
	 * @return void
	 *
	 */
	public function homlist_app_notice_dismiss() {
		if ( check_ajax_referer( "dismissnotice", "nonce" ) ) {
			if ( isset( $_POST['dismiss'] ) && $_POST['dismiss'] == 1 ) {
				set_transient( "homlisti_dismiss_notice", 1, MONTH_IN_SECONDS * 2 );
				wp_die( "done" );
			}
		}
	}

	/**
	 * Old Custom Fields ajax callback
	 *
	 * @return void
	 */
	function rtcl_cf_by_category_func() {


		$fb_id  = ! empty( $_REQUEST['fb_id'] ) ? sanitize_text_field( $_REQUEST['fb_id'] ) : '';
		$cat_id = ! empty( $_REQUEST['cat_id'] ) ? sanitize_text_field( $_REQUEST['cat_id'] ) : '';

		if ( $fb_id ) {
			Listing_Functions::get_cf_fields_demand( $fb_id, '', $cat_id );
		} else {
			if ( 'all' == $cat_id ) {
				$args      = [ 'is_searchable' => true ];
				$fields_id = Functions::get_cf_ids( $args );
			} else {
				$fields_id = self::get_cf_ids( $_POST['cat_id'] );
			}

			$html = '';

			foreach ( $fields_id as $field ) {
				$html .= Listing_Functions::get_advanced_search_field_html( $field );
			}
			printf( "%s", $html );
		}


		do_action( 'homlisti_after_custom_field' );

		if ( isset( $_POST['price_search'] ) && $_POST['price_search'] == 'yes' ): ?>
            <div class="search-item">
                <div class="price-range">
                    <label><?php esc_html_e( 'Price', 'homlisti' ); ?></label>
					<?php
					$data_form = '';
					$data_to   = '';
					if ( isset( $_GET['filters']['price']['min'] ) ) {
						$data_form .= sprintf( "data-from=%s", absint( $_GET['filters']['price']['min'] ) );
					}
					if ( isset( $_GET['filters']['price']['max'] ) && ! empty( $_GET['filters']['price']['max'] ) ) {
						$data_to .= sprintf( "data-to=%s", absint( $_GET['filters']['price']['max'] ) );
					}

					$listing_price_range = Helper::listing_price_range();
					$_min_price          = $_POST['price']['minPrice'] ?? $listing_price_range['min_price'];
					$_max_price          = $_POST['price']['maxPrice'] ?? $listing_price_range['max_price'];

					global $rtclmcData;
					if ( ! is_array( $rtclmcData ) && class_exists( 'RtclMc_Frontend_Price_Filters' ) ) {
						$RtclMc_Frontend_Price_Filters = \RtclMc_Frontend_Price_Filters::instance();
						$rtclmcData                    = $RtclMc_Frontend_Price_Filters->getCurrencyData();
					}

					$currency_symbol = Functions::get_currency_symbol();
					if ( isset( $rtclmcData['currency'] ) && ! empty( $rtclmcData['currency'] ) ) {
						$currency_symbol = Functions::get_currency_symbol( $rtclmcData['currency'] );
					}

					$currency_pos           = Functions::get_option_item( 'rtcl_general_settings', 'currency_position', 'left' );
					$data_currency_position = sprintf( "data-prefix=%s", $currency_symbol );
					if ( in_array( $currency_pos, [ 'right', 'right_space' ] ) ) {
						$data_currency_position = sprintf( "data-postfix=%s", $currency_symbol );
					}

					?>

                    <input type="number" class="ion-rangeslider"
						<?php echo esc_attr( $data_form ); ?>
						<?php echo esc_attr( $data_to ); ?>
						<?php echo esc_attr( $data_currency_position ); ?>
                           data-min="<?php echo esc_attr( $_min_price ) ?>"
                           data-max="<?php echo esc_attr( $_max_price ) ?>"
                    />
                    <input type="hidden" class="min-volumn" name="filters[price][min]"
                           value="<?php if ( isset( $_GET['filters']['price']['min'] ) ) {
						       echo absint( $_GET['filters']['price']['min'] );
					       } ?>">
                    <input type="hidden" class="max-volumn" name="filters[price][max]"
                           value="<?php if ( isset( $_GET['filters']['price']['max'] ) ) {
						       echo absint( $_GET['filters']['price']['max'] );
					       } ?>">
                </div>
            </div>
		<?php endif;


		wp_die();
	}


	public static function get_cf_ids( $category_id ) {
		$group_id = AppliedBothEndHooks::get_custom_field_group_ids( null, $category_id );
		$args     = [
			'post_type'        => rtcl()->post_type_cf,
			'post_status'      => 'publish',
			'posts_per_page'   => - 1,
			'fields'           => 'ids',
			'suppress_filters' => false,
			'orderby'          => 'menu_order',
			'order'            => 'ASC',
			'post_parent__in'  => $group_id,
			'meta_query'       => [
				[
					'key'   => '_searchable',
					'value' => 1
				],
			]
		];

		return get_posts( $args );
	}

}

HomlistiAjax::instance();