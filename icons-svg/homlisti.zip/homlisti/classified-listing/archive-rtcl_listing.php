<?php
/**
 * @package ClassifiedListing/Templates
 * @version 1.5.4
 */

use radiustheme\HomListi\Helper;
use radiustheme\HomListi\RDTheme;
use Rtcl\Helpers\Functions;
use RtclPro\Helpers\Fns;

defined( 'ABSPATH' ) || exit;

get_header( 'listing' );

/**
 * Hook: rtcl_before_main_content.
 *
 * @hooked rtcl_output_content_wrapper - 10 (outputs opening divs for the content)
 */
do_action( 'rtcl_before_main_content' );
$full_width = isset( $_GET['layout'] ) ? sanitize_text_field( wp_unslash( $_GET['layout'] ) ) : null;

$search_bar_title = esc_html__( 'Advanced Search', 'homlisti' );
$get_sidebar_list = get_option( 'sidebars_widgets' );
$widget_number    = '0';
if ( ! empty( $get_sidebar_list['listing-archive-sidebar'][0] ) ) {
	$widget_no     = (int) substr( $get_sidebar_list['listing-archive-sidebar'][0], - 1 );
	$widget_number = $widget_no > 0 ? $widget_no : 0;
}
$search_title = get_option( 'widget_homlisti_advanced_search' );
if ( ! empty( $search_title[ $widget_number ] ) ) {
	$search_bar_title = $search_title[ $widget_number ]['title'];
}

//Map enabled

$container = 'container';
$has_map   = false;
if ( Helper::is_map_enabled() ) {
	global $rtcl_has_map_data;
	$rtcl_has_map_data = 1;
	$container         = 'container-fluid has-map';
	$has_map           = true;
}
?>
    <div class="<?php echo esc_attr( $container ); ?> rtcl-widget-border-enable rtcl-widget-is-sticky listing-title-wrap-enable rtcl-listing-archive">
		<?php do_action( 'homlisti_listing_loop_top_actions' ); ?>

        <div class="archive-top-sidebar">
			<?php if ( is_active_sidebar( 'listing-archive-to-sidebar' ) ) : ?>
				<?php dynamic_sidebar( 'listing-archive-to-sidebar' ) ?>
			<?php else : ?>
                <div class='listing-inner rt-advanced-search-wrapper rtcl-archive-top-search-wrapper'>
                    <h2><?php echo esc_html( $search_bar_title ); ?></h2>
					<?php //do_action('homlisti_listing_grid_search_filer'); ?>
					<?php dynamic_sidebar( 'listing-archive-sidebar' ) ?>
                </div>
			<?php endif; ?>
        </div>

        <div class="row product-grid product-grid-inner pb-5">


			<?php if ( $has_map ) : ?>
            <div class="col-7 map-left-side-content">
                <div class="row">
					<?php endif; ?>

                    <div class="<?php if ( $full_width == 'fullwidth' ) {
						echo "col-sm-12 col-12 col-8";
					} else {
						Helper::the_layout_class();
					} ?>">
						<?php
						if ( rtcl()->wp_query()->have_posts() ) {
							?>
                            <div class="product-wrap">
								<?php
								/**
								 * Hook: rtcl_before_listing_loop.
								 *
								 * @hooked TemplateHooks::output_all_notices() - 10
								 * @hooked TemplateHooks::listings_actions - 20
								 *
								 */
								do_action( 'rtcl_before_listing_loop' );


								Functions::listing_loop_start();

								/**
								 * Top listings
								 */
								if ( class_exists( 'RtclPro' ) && Fns::is_enable_top_listings() ) {
									do_action( 'rtcl_listing_loop_prepend_data' );
								}

								while ( rtcl()->wp_query()->have_posts() ) : rtcl()->wp_query()->the_post();
									/**
									 * Hook: rtcl_listing_loop.
									 */
									do_action( 'rtcl_listing_loop' );

									Functions::get_template_part( 'content', 'listing' );
								endwhile;

								Functions::listing_loop_end();
								?>
                            </div>
							<?php
							/**
							 * Hook: rtcl_after_listing_loop.
							 *
							 * @hooked TemplateHook::pagination() - 10
							 */
							do_action( 'rtcl_after_listing_loop' );
						} else {
							/**
							 * Top listings
							 */
							if ( class_exists( 'RtclPro' ) && Fns::is_enable_top_listings() ) {
								Functions::listing_loop_start();
								do_action( 'rtcl_top_listings' );
								Functions::listing_loop_end();
							}

							/**
							 * Hook: rtl_no_listings_found.
							 *
							 * @hooked no_listings_found - 10
							 */
							do_action( 'rtcl_no_listings_found' );
						}
						?>
                    </div>
					<?php
					if ( Helper::has_sidebar() && $full_width != 'fullwidth' ) {
						do_action( 'rtcl_sidebar' );
					}
					?>
					<?php if ( $has_map ) : ?>
                </div>
            </div>
            <div class="col-5 map-right-side-content">
                <div class="rtcl-search-map rtcl-archive-map-embed">
                    <div class="rtcl-map-view" data-map-type="search"></div>
                </div>
            </div>

		<?php endif; ?>
        </div>
        <!--.row end-->

    </div>


<?php

if ( function_exists( '_mc4wp_load_plugin' ) && RDTheme::$options['newsletter_section'] ) {
	get_template_part( 'template-parts/rt', 'newsletter' );
}

/**
 * Hook: rtcl_after_main_content.
 *
 * @hooked rtcl_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'rtcl_after_main_content' );

get_footer( 'listing' );
