<?php
/**
 * Content wrappers
 *
 * @package     ClassifiedListing/Templates
 * @version     1.4.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
</div>