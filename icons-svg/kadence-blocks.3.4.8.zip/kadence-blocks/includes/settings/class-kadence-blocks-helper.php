<?php
/**
 * Main plugin class
 */
final class Kadence_Blocks_Helper {

	public const KEY = '';

}
